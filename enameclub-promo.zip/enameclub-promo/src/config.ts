// Voiceover preview switches. The voiceover is NEVER part of the render unless you flip the second flag.
export const VOICEOVER_FILE = "voiceover.mp3"; // put it in public/
export const PLAY_VOICEOVER_IN_STUDIO = true; // plays in Remotion Studio when public/voiceover.mp3 exists
export const PLAY_VOICEOVER_IN_RENDER = false; // keep false: the render carries SFX only
