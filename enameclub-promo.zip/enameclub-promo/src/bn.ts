const D = "০১২৩৪৫৬৭৮৯";
export const bnDigits = (s: string) => s.replace(/[0-9]/g, (d) => D[Number(d)]);
/** 1699 -> "১,৬৯৯" */
export const bnNum = (n: number) => bnDigits(n.toLocaleString("en-US"));
