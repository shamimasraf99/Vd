// Single source of truth. Scheme: "Royal Trust" (scheme 1).
// Components never hold a hex colour, easing curve, spring config or font name.
import { Easing } from "remotion";
import { fontFamily } from "./fonts";

const c = {
  bg: "#0A1A3F",
  bgDeep: "#071230",
  bgAlt: "#112B63",
  hero: "#0B4DB5", // logo blue — used for fills, never for text on the dark base
  heroLight: "#2A74E0",
  accent: "#3FA9FF",
  text: "#F4F8FF",
  textDim: "#A9BCDD",
  white: "#FFFFFF",
  glow: "rgba(63,169,255,0.45)",
  heroGlow: "rgba(11,77,181,0.55)",
  border: "rgba(255,255,255,0.14)",
  borderStrong: "rgba(255,255,255,0.30)",
  surface: "rgba(255,255,255,0.06)",
  skeleton: "rgba(255,255,255,0.11)",
  dot: "rgba(255,255,255,0.07)",
  shade: "rgba(2,8,24,0.55)",
};

export const theme = {
  colors: c,
  fonts: {
    main: `"${fontFamily}", "Hind Siliguri", "Noto Sans Bengali", sans-serif`,
  },
  radius: { sm: 16, md: 28, lg: 40 },
  shadow: {
    card: "0 30px 70px -20px rgba(2,8,24,0.65)",
  },
  gradients: {
    bg: `linear-gradient(160deg, ${c.bgAlt} 0%, ${c.bg} 45%, ${c.bgDeep} 100%)`,
    glass: "linear-gradient(145deg, rgba(255,255,255,0.13), rgba(255,255,255,0.04))",
    gloss: "linear-gradient(115deg, rgba(255,255,255,0.20) 0%, rgba(255,255,255,0) 38%)",
    hero: `linear-gradient(135deg, ${c.heroLight}, ${c.hero})`,
    sweep: `linear-gradient(100deg, ${c.hero}, ${c.heroLight})`,
    text: `linear-gradient(100deg, ${c.accent} 0%, ${c.text} 100%)`,
    ray: `linear-gradient(180deg, ${c.accent}, rgba(63,169,255,0))`,
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // entrances
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // moves
    in: Easing.bezier(0.7, 0, 0.84, 0), // exits only
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
    count: { damping: 26, stiffness: 90, mass: 1 },
  },
  timing: {
    wordStagger: 4,
    cardStagger: 5,
    exit: 9,
  },
} as const;
