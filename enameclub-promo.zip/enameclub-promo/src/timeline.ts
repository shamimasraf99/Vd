// All timing is derived from the SRT (via src/cues.ts). Nothing is placed by hand.
import { cues } from "./cues";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export const LEAD = 6; // a scene starts this many frames before its first cue (visuals lead the words by 4-6 frames)
export const OVERLAP = 10; // frames a scene keeps living after the next one starts (hidden by the sweep)
export const SEQ_TAIL = 16; // extra mounted frames so late SFX of the outgoing scene are not cut

export const msToFrame = (ms: number) => Math.round((ms / 1000) * FPS);

export type LocalCue = { index: number; text: string; start: number; end: number };
export type SceneProps = { cues: LocalCue[]; duration: number; exitAt?: number };
export type SceneId = "hook" | "mockup" | "offer" | "numbers" | "domain" | "presence" | "payments" | "cta";

// Scene boundaries always sit on cue boundaries (1-based cue numbers, inclusive).
const PLAN: { id: SceneId; cueFrom: number; cueTo: number }[] = [
  { id: "hook", cueFrom: 1, cueTo: 1 },
  { id: "mockup", cueFrom: 2, cueTo: 2 },
  { id: "offer", cueFrom: 3, cueTo: 3 },
  { id: "numbers", cueFrom: 4, cueTo: 4 },
  { id: "domain", cueFrom: 5, cueTo: 5 },
  { id: "presence", cueFrom: 6, cueTo: 6 },
  { id: "payments", cueFrom: 7, cueTo: 7 },
  { id: "cta", cueFrom: 8, cueTo: 9 },
];

export const TOTAL_FRAMES = msToFrame(cues[cues.length - 1].endMs);

export const SCENES = PLAN.map((p, i) => {
  const first = cues[p.cueFrom - 1];
  const last = cues[p.cueTo - 1];
  const isFirst = i === 0;
  const isLast = i === PLAN.length - 1;
  const from = isFirst ? 0 : msToFrame(first.startMs) - LEAD;
  const to = isLast ? TOTAL_FRAMES : msToFrame(last.endMs) - LEAD + OVERLAP;
  const duration = to - from;
  const local: LocalCue[] = cues.slice(p.cueFrom - 1, p.cueTo).map((c) => ({
    index: c.index,
    text: c.text,
    start: msToFrame(c.startMs) - from,
    end: msToFrame(c.endMs) - from,
  }));
  return {
    id: p.id,
    from,
    duration,
    seqDuration: isLast ? duration : duration + SEQ_TAIL,
    exitAt: isLast ? undefined : duration - OVERLAP,
    cues: local,
  };
});

/**
 * Local frame at which a phrase is spoken, estimated from its character position inside the cue
 * (cue start/end come from the SRT), minus a small lead so the visual lands just before the words.
 */
export const phraseAt = (cue: LocalCue, phrase: string, lead = 5) => {
  const idx = cue.text.indexOf(phrase);
  const frac = idx < 0 ? 0 : idx / cue.text.length;
  return Math.max(0, Math.round(cue.start + frac * (cue.end - cue.start) - lead));
};
