// Hind Siliguri: correct Bengali conjuncts (যুক্তাক্ষর), heavy weights for titles.
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

const loaded = loadFont("normal", {
  weights: ["400", "500", "600", "700"],
  subsets: ["bengali", "latin", "latin-ext"],
});

export const fontFamily = loaded.fontFamily;
