import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { SCENES, type SceneId, type SceneProps } from "./timeline";
import { PreviewAudio } from "./components/PreviewAudio";
import { SweepPanel, SWEEP_FRAMES } from "./components/SweepPanel";
import { S1Hook } from "./scenes/S1Hook";
import { S2Mockup } from "./scenes/S2Mockup";
import { S3Offer } from "./scenes/S3Offer";
import { S4Numbers } from "./scenes/S4Numbers";
import { S5Domain } from "./scenes/S5Domain";
import { S6Presence } from "./scenes/S6Presence";
import { S7Payments } from "./scenes/S7Payments";
import { S8Cta } from "./scenes/S8Cta";

const COMPONENTS: Record<SceneId, React.FC<SceneProps>> = {
  hook: S1Hook,
  mockup: S2Mockup,
  offer: S3Offer,
  numbers: S4Numbers,
  domain: S5Domain,
  presence: S6Presence,
  payments: S7Payments,
  cta: S8Cta,
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bgDeep, fontFamily: theme.fonts.main }}>
    {SCENES.map((s) => {
      const Scene = COMPONENTS[s.id];
      return (
        <Sequence key={s.id} name={s.id} from={s.from} durationInFrames={s.seqDuration}>
          <Scene cues={s.cues} duration={s.duration} exitAt={s.exitAt} />
        </Sequence>
      );
    })}
    {/* transition wipes: the cut is hidden at the panel's midpoint */}
    {SCENES.slice(1).map((s) => (
      <Sequence
        key={`sweep-${s.id}`}
        name={`sweep-${s.id}`}
        from={s.from - Math.round(SWEEP_FRAMES / 2)}
        durationInFrames={SWEEP_FRAMES + 14}
      >
        <SweepPanel />
      </Sequence>
    ))}
    <PreviewAudio />
  </AbsoluteFill>
);
