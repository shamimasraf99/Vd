import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { SceneFrame } from "../components/Layers";
import { Words } from "../components/Text";
import { Glass, LockIcon, Pill, Skel } from "../components/Ui";
import { clamp01, sp, tween } from "../components/anim";
import { Sfx } from "../components/Sfx";
import { phraseAt, type SceneProps } from "../timeline";

// Style: Glossy UI Mockup (a website assembling itself)
export const S2Mockup: React.FC<SceneProps> = ({ cues, exitAt }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const cue = cues[0];
  const tEasy = phraseAt(cue, "সহজ");
  const tCheap = phraseAt(cue, "সাশ্রয়ী");

  const win = sp(frame, fps, 4, theme.spring.smooth);
  const float = Math.sin(frame / 30) * 6;
  const shine = tween(frame, 52, 92, -60, 160, theme.ease.inOut);
  const b = (d: number) => clamp01(sp(frame, fps, d, theme.spring.snappy));

  return (
    <SceneFrame seed={2} exitAt={exitAt}>
      <AbsoluteFill style={{ flexDirection: "row", alignItems: "center", padding: "0 110px", columnGap: 40 }}>
        {/* left: message */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "flex-start", rowGap: 18 }}>
          <Words text="নিজস্ব ওয়েবসাইট" size={118} weight={700} delay={4} per={6} align="flex-start" />
          <Words
            text="তৈরির স্বপ্ন"
            size={70}
            weight={500}
            delay={16}
            color={theme.colors.textDim}
            align="flex-start"
          />
          <div style={{ display: "flex", columnGap: 24, marginTop: 26 }}>
            <Pill label="সহজ" delay={tEasy} />
            <Pill label="সাশ্রয়ী" delay={tCheap} />
          </div>
        </div>

        {/* right: browser mock-up */}
        <div
          style={{
            width: 850,
            opacity: clamp01(win * 1.5),
            transform: `perspective(2000px) rotateY(-12deg) rotateX(3deg) translateX(${(1 - win) * 140}px) translateY(${float}px) scale(${0.92 + 0.08 * win})`,
          }}
        >
          <Glass style={{ borderRadius: theme.radius.md }} contentStyle={{ display: "flex", flexDirection: "column" }}>
            {/* chrome */}
            <div
              style={{
                height: 64,
                display: "flex",
                alignItems: "center",
                columnGap: 12,
                padding: "0 24px",
                borderBottom: `1.5px solid ${theme.colors.border}`,
                opacity: b(6),
              }}
            >
              {[0, 1, 2].map((i) => (
                <div key={i} style={{ width: 16, height: 16, borderRadius: 8, background: theme.colors.borderStrong }} />
              ))}
              <div
                style={{
                  marginLeft: 18,
                  height: 34,
                  width: 440,
                  borderRadius: 17,
                  background: theme.colors.skeleton,
                  display: "flex",
                  alignItems: "center",
                  columnGap: 10,
                  padding: "0 14px",
                }}
              >
                <LockIcon size={18} />
                <div style={{ height: 10, width: 180, borderRadius: 5, background: theme.colors.borderStrong }} />
              </div>
            </div>

            <div style={{ padding: 36, display: "flex", flexDirection: "column", rowGap: 28 }}>
              {/* nav */}
              <div style={{ display: "flex", alignItems: "center", columnGap: 16 }}>
                <Skel p={b(14)} w={44} h={44} r={22} fill={theme.colors.accent} />
                <Skel p={b(17)} w={90} h={16} r={8} />
                <Skel p={b(20)} w={90} h={16} r={8} />
                <Skel p={b(23)} w={90} h={16} r={8} />
              </div>
              {/* hero */}
              <div style={{ display: "flex", columnGap: 28, alignItems: "center" }}>
                <div style={{ flex: 1, display: "flex", flexDirection: "column", rowGap: 14 }}>
                  <Skel p={b(20)} w={360} h={34} r={12} fill={theme.colors.borderStrong} />
                  <Skel p={b(24)} w={290} h={34} r={12} fill={theme.colors.borderStrong} />
                  <Skel p={b(28)} w={340} h={16} r={8} style={{ marginTop: 8 }} />
                  <Skel p={b(31)} w={300} h={16} r={8} />
                  <Skel p={b(35)} w={176} h={54} r={27} fill={theme.colors.hero} style={{ marginTop: 10 }} />
                </div>
                <div style={{ position: "relative", width: 300, height: 232 }}>
                  <Skel p={b(26)} w={300} h={232} r={26} fill={theme.colors.surface} style={{ border: `1.5px solid ${theme.colors.border}` }} />
                  <div
                    style={{
                      position: "absolute",
                      left: 54,
                      top: 50,
                      width: 70,
                      height: 70,
                      borderRadius: 35,
                      background: theme.colors.accent,
                      opacity: b(34),
                    }}
                  />
                  <div
                    style={{
                      position: "absolute",
                      left: 40,
                      bottom: 36,
                      width: 220,
                      height: 12,
                      borderRadius: 6,
                      background: theme.colors.borderStrong,
                      opacity: b(38),
                    }}
                  />
                </div>
              </div>
              {/* cards */}
              <div style={{ display: "flex", columnGap: 22 }}>
                {[40, 45, 50].map((d) => (
                  <Skel
                    key={d}
                    p={b(d)}
                    w="100%"
                    h={118}
                    r={22}
                    fill={theme.colors.surface}
                    style={{ flex: 1, border: `1.5px solid ${theme.colors.border}` }}
                  />
                ))}
              </div>
            </div>

            {/* glossy shine */}
            <div
              style={{
                position: "absolute",
                top: 0,
                bottom: 0,
                left: `${shine}%`,
                width: "26%",
                transform: "skewX(-18deg)",
                background: theme.gradients.gloss,
                opacity: 0.8,
                pointerEvents: "none",
              }}
            />
          </Glass>
        </div>
      </AbsoluteFill>
      <Sfx name="pop" at={5} />
      <Sfx name="click" at={tEasy - 3} />
      <Sfx name="click" at={tCheap - 3} rate={1.08} />
    </SceneFrame>
  );
};
