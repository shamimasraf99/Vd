import React from "react";
import { AbsoluteFill, Img, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { SceneFrame } from "../components/Layers";
import { MarkerSweep, Words } from "../components/Text";
import { clamp01, sp, tween } from "../components/anim";
import { Sfx } from "../components/Sfx";
import { phraseAt, type SceneProps } from "../timeline";

const RAYS = 16;
const TILE = 300;

// Style: Logo reveal + radial rays, then the offer line
export const S3Offer: React.FC<SceneProps> = ({ cues, duration, exitAt }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tPill = phraseAt(cues[0], "বিশেষ ওয়েব");
  const logo = sp(frame, fps, 3, theme.spring.bouncy);
  const word = sp(frame, fps, 12, theme.spring.smooth);
  const zoom = tween(frame, 0, duration, 1, 1.06, theme.ease.inOut); // Ken Burns on the still logo

  return (
    <SceneFrame seed={3} exitAt={exitAt}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", rowGap: 34 }}>
          <div style={{ position: "relative", width: TILE, height: TILE }}>
            {Array.from({ length: RAYS }).map((_, i) => {
              const p = clamp01(sp(frame, fps, 6 + i * 1.2, theme.spring.snappy));
              const len = (150 + (i % 2) * 70) * p * (1 + Math.sin(frame / 24 + i) * 0.06);
              return (
                <div
                  key={i}
                  style={{
                    position: "absolute",
                    left: "50%",
                    top: "50%",
                    width: 5,
                    height: len,
                    borderRadius: 4,
                    background: theme.gradients.ray,
                    opacity: 0.55,
                    transformOrigin: "50% 0%",
                    transform: `translateX(-50%) rotate(${(360 / RAYS) * i + frame * 0.2}deg) translateY(${TILE * 0.62}px)`,
                  }}
                />
              );
            })}
            <div
              style={{
                position: "absolute",
                inset: 0,
                borderRadius: 64,
                overflow: "hidden",
                background: theme.colors.white,
                boxShadow: `0 0 90px ${theme.colors.glow}, ${theme.shadow.card}`,
                opacity: clamp01(logo * 2),
                transform: `scale(${0.35 + 0.65 * logo}) rotate(${(1 - logo) * -14}deg)`,
              }}
            >
              <Img
                src={staticFile("logo-enameclub.jpg")}
                style={{ width: "100%", height: "100%", objectFit: "contain", transform: `scale(${zoom})` }}
              />
            </div>
          </div>

          <div
            style={{
              fontSize: 150,
              fontWeight: 700,
              lineHeight: 1.25,
              letterSpacing: 0,
              color: theme.colors.text,
              opacity: clamp01(word * 1.4),
              transform: `translateY(${(1 - word) * 40}px) scale(${0.94 + 0.06 * word})`,
            }}
          >
            Ename<span style={{ color: theme.colors.accent }}>Club</span>
          </div>

          <div style={{ display: "flex", alignItems: "center", columnGap: 24, fontSize: 72, fontWeight: 600, lineHeight: 1.3 }}>
            <Words text="বিশেষ ওয়েব হোস্টিং" size={72} weight={600} delay={tPill} per={5} />
            <MarkerSweep delay={tPill + 16} padX={26} radius={18}>
              <span style={{ fontWeight: 700 }}>অফার</span>
            </MarkerSweep>
          </div>
        </div>
      </AbsoluteFill>
      <Sfx name="chime" at={2} />
      <Sfx name="pop" at={tPill - 3} />
    </SceneFrame>
  );
};
