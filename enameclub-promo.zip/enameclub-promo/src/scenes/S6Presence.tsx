import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SceneFrame } from "../components/Layers";
import { MarkerSweep, Words } from "../components/Text";
import { clamp01, tween } from "../components/anim";
import { Sfx } from "../components/Sfx";
import { phraseAt, type SceneProps } from "../timeline";

// Rising line = decorative growth path (no numbers)
const PTS: [number, number][] = [
  [140, 960], [420, 905], [700, 860], [980, 790], [1260, 665], [1540, 540], [1780, 415],
];
const LINE = PTS.map(([x, y]) => `${x},${y}`).join(" ");
const AREA = `${LINE} 1780,1080 140,1080`;

// Style: Minimal Clean statement + Line Draw (a pause between feature scenes)
export const S6Presence: React.FC<SceneProps> = ({ cues, exitAt }) => {
  const frame = useCurrentFrame();
  const cue = cues[0];
  const tOnline = phraseAt(cue, "অনলাইন");
  const tEasy = phraseAt(cue, "সহজেই");

  const prog = tween(frame, cue.start + 6, cue.end - 18, 0, 1, theme.ease.inOut);
  const clipW = 140 + (1780 - 140) * prog;
  const pulse = (frame % 45) / 45;
  const last = PTS[PTS.length - 1];

  return (
    <SceneFrame seed={6} exitAt={exitAt}>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", inset: 0 }}>
        <defs>
          <linearGradient id="presenceFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={theme.colors.accent} stopOpacity={0.3} />
            <stop offset="100%" stopColor={theme.colors.accent} stopOpacity={0} />
          </linearGradient>
          <clipPath id="presenceClip">
            <rect x={0} y={0} width={clipW} height={1080} />
          </clipPath>
        </defs>
        <polygon points={AREA} fill="url(#presenceFill)" clipPath="url(#presenceClip)" />
        <polyline
          points={LINE}
          fill="none"
          stroke={theme.colors.accent}
          strokeWidth={6}
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
          strokeDasharray={1}
          strokeDashoffset={1 - prog}
          opacity={prog > 0.01 ? 1 : 0}
        />
        {PTS.map(([x, y], i) => {
          const q = clamp01((prog - i / (PTS.length - 1) + 0.04) * 14);
          return <circle key={i} cx={x} cy={y} r={13 * q} fill={theme.colors.text} />;
        })}
        {prog > 0.97 ? (
          <circle
            cx={last[0]}
            cy={last[1]}
            r={18 + pulse * 40}
            fill="none"
            stroke={theme.colors.accent}
            strokeWidth={3}
            opacity={1 - pulse}
          />
        ) : null}
      </svg>

      <AbsoluteFill style={{ justifyContent: "flex-start", paddingLeft: 140, paddingTop: 170 }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", rowGap: 6 }}>
          <Words text="আপনার ব্যবসার" size={76} weight={500} delay={3} color={theme.colors.textDim} align="flex-start" />
          <Words
            text="অনলাইন উপস্থিতি"
            size={150}
            weight={700}
            delay={tOnline}
            per={6}
            accentWords={["উপস্থিতি"]}
            align="flex-start"
          />
          <div style={{ display: "flex", alignItems: "center", columnGap: 26, marginTop: 10, fontSize: 84, fontWeight: 600, lineHeight: 1.3 }}>
            <Words text="গড়ে তুলুন" size={84} weight={600} delay={tOnline + 14} align="flex-start" />
            <MarkerSweep delay={tEasy} padX={26} radius={18}>
              <span style={{ fontWeight: 700 }}>সহজেই</span>
            </MarkerSweep>
          </div>
        </div>
      </AbsoluteFill>
      <Sfx name="pop" at={tOnline - 3} />
      <Sfx name="click" at={tEasy - 3} />
    </SceneFrame>
  );
};
