import React from "react";
import { AbsoluteFill, Img, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { SceneFrame } from "../components/Layers";
import { Words } from "../components/Text";
import { CheckIcon, Glass, LockIcon } from "../components/Ui";
import { clamp01, sp, tween } from "../components/anim";
import { Sfx } from "../components/Sfx";
import { phraseAt, type SceneProps } from "../timeline";

const URL_TEXT = "www.enameclub.com";
// recap uses only facts from the script
const RECAP = [
  { top: "১,৬৯৯ টাকা", bottom: "১০ জিবি হোস্টিং" },
  { top: "ফ্রি .COM", bottom: "ডোমেইন" },
  { top: "বিকাশ, নগদ", bottom: "ও রকেট" },
];

// Style: Checklist Recap Grid (cue 8), then a clean CTA / brand close (cue 9)
export const S8Cta: React.FC<SceneProps> = ({ cues, duration }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const [, c9] = cues;
  const stageB = c9.start - 5;
  const tLogo = phraseAt(c9, "EnameClub —");
  const tTag = phraseAt(c9, "আপনার অনলাইন যাত্রার");
  const tType = stageB + 10;
  const typeLen = 42;

  const aExit = tween(frame, stageB - 12, stageB - 3, 0, 1, theme.ease.in);
  const bar = sp(frame, fps, stageB, theme.spring.smooth);
  const logo = sp(frame, fps, tLogo, theme.spring.bouncy);
  const shown = Math.floor(tween(frame, tType, tType + typeLen, 0, URL_TEXT.length + 0.99, theme.ease.out));
  const caret = Math.floor(frame / 8) % 2 === 0 ? 1 : 0;
  const breathe = 1 + Math.sin(frame / 22) * 0.008;
  const zoom = tween(frame, 0, duration, 1, 1.05, theme.ease.inOut);

  return (
    <SceneFrame seed={8}>
      {/* stage A: recap grid */}
      <AbsoluteFill
        style={{
          alignItems: "center",
          justifyContent: "center",
          opacity: 1 - aExit,
          transform: `translateY(${-aExit * 40}px)`,
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", rowGap: 80 }}>
          <Words text="আজই ভিজিট করুন" size={140} weight={700} delay={4} per={5} accentWords={["ভিজিট"]} />
          <div style={{ display: "flex", columnGap: 36 }}>
            {RECAP.map((r, i) => {
              const d = 20 + i * 5;
              const p = sp(frame, fps, d, theme.spring.smooth);
              const check = tween(frame, d + 8, d + 20, 0, 1);
              return (
                <div
                  key={r.top}
                  style={{
                    opacity: clamp01(p * 1.4),
                    transform: `translateY(${(1 - p) * 60}px) scale(${0.94 + 0.06 * p})`,
                  }}
                >
                  <Glass
                    style={{ width: 520, height: 190, borderRadius: theme.radius.md }}
                    contentStyle={{ display: "flex", alignItems: "center", columnGap: 26, padding: "0 36px" }}
                  >
                    <CheckIcon size={58} progress={check} />
                    <div style={{ display: "flex", flexDirection: "column", letterSpacing: 0 }}>
                      <div style={{ fontSize: 56, fontWeight: 700, lineHeight: 1.3 }}>{r.top}</div>
                      <div style={{ fontSize: 40, fontWeight: 500, lineHeight: 1.3, color: theme.colors.textDim }}>
                        {r.bottom}
                      </div>
                    </div>
                  </Glass>
                </div>
              );
            })}
          </div>
        </div>
      </AbsoluteFill>

      {/* stage B: URL + brand */}
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", rowGap: 56 }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              columnGap: 30,
              opacity: clamp01(logo * 1.6),
              transform: `translateY(${(1 - logo) * 40}px) scale(${0.8 + 0.2 * logo})`,
            }}
          >
            <div
              style={{
                width: 130,
                height: 130,
                borderRadius: 32,
                overflow: "hidden",
                background: theme.colors.white,
                boxShadow: theme.shadow.card,
              }}
            >
              <Img
                src={staticFile("logo-enameclub.jpg")}
                style={{ width: "100%", height: "100%", objectFit: "contain", transform: `scale(${zoom})` }}
              />
            </div>
            <div style={{ fontSize: 100, fontWeight: 700, lineHeight: 1.25, letterSpacing: 0 }}>
              Ename<span style={{ color: theme.colors.accent }}>Club</span>
            </div>
          </div>

          <div
            style={{
              opacity: clamp01(bar * 1.4),
              transform: `scale(${(0.9 + 0.1 * bar) * breathe}) translateY(${(1 - bar) * 50}px)`,
            }}
          >
            <Glass
              fill="hero"
              style={{
                width: 1180,
                height: 160,
                borderRadius: 80,
                boxShadow: `0 0 90px ${theme.colors.glow}, ${theme.shadow.card}`,
              }}
              contentStyle={{ display: "flex", alignItems: "center", justifyContent: "center", columnGap: 26 }}
            >
              <LockIcon size={56} color={theme.colors.text} />
              <div style={{ fontSize: 80, fontWeight: 600, lineHeight: 1.3, letterSpacing: 0, minWidth: 820 }}>
                {URL_TEXT.slice(0, shown)}
                <span style={{ opacity: caret, color: theme.colors.accent }}>|</span>
              </div>
            </Glass>
          </div>

          <Words
            text="আপনার অনলাইন যাত্রার বিশ্বস্ত সঙ্গী"
            size={70}
            weight={600}
            delay={tTag}
            per={5}
            accentWords={["বিশ্বস্ত", "সঙ্গী"]}
            maxWidth={1500}
          />
        </div>
      </AbsoluteFill>

      <Sfx name="pop" at={1} />
      <Sfx name="pop" at={17} rate={1.05} />
      <Sfx name="pop" at={stageB - 2} rate={0.95} />
      <Sfx name="click" at={tType + typeLen} />
      <Sfx name="chime" at={tLogo - 3} />
    </SceneFrame>
  );
};
