import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { SceneFrame } from "../components/Layers";
import { CardIcon, Glass } from "../components/Ui";
import { clamp01, sp, tween } from "../components/anim";
import { Sfx } from "../components/Sfx";
import type { SceneProps } from "../timeline";

const HUB = { x: 960, y: 560 };
const HUB_SIZE = 300;
const NODE_W = 380;
const NODE_H = 140;
// no logo files were supplied, so the three services are shown as text
const NODES = [
  { name: "বিকাশ", x: 553, y: 395 },
  { name: "নগদ", x: 1367, y: 395 },
  { name: "রকেট", x: 960, y: 890 },
];

// Style: Hub and Spoke. Node reveals are spaced equally across the cue.
export const S7Payments: React.FC<SceneProps> = ({ cues, exitAt }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const cue = cues[0];
  const dur = cue.end - cue.start;
  const times = NODES.map((_, k) => Math.round(cue.start + dur * (0.2 + 0.22 * k)) - 5);

  const hub = sp(frame, fps, 3, theme.spring.bouncy);
  const ring = (frame % 60) / 60;

  return (
    <SceneFrame seed={7} exitAt={exitAt}>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", inset: 0 }}>
        {NODES.map((n, k) => {
          const draw = tween(frame, times[k], times[k] + 12, 0, 1, theme.ease.out);
          const t = ((frame - times[k] - 12) % 45) / 45;
          const dotOn = frame > times[k] + 12;
          return (
            <g key={n.name}>
              <line
                x1={HUB.x}
                y1={HUB.y}
                x2={n.x}
                y2={n.y}
                stroke={theme.colors.accent}
                strokeWidth={3}
                strokeLinecap="round"
                pathLength={1}
                strokeDasharray={1}
                strokeDashoffset={1 - draw}
                opacity={draw > 0.01 ? 0.7 : 0}
              />
              {dotOn ? (
                <circle
                  cx={HUB.x + (n.x - HUB.x) * t}
                  cy={HUB.y + (n.y - HUB.y) * t}
                  r={8}
                  fill={theme.colors.text}
                />
              ) : null}
            </g>
          );
        })}
      </svg>

      {/* hub */}
      <div
        style={{
          position: "absolute",
          left: HUB.x - HUB_SIZE / 2,
          top: HUB.y - HUB_SIZE / 2,
          width: HUB_SIZE,
          height: HUB_SIZE,
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: HUB_SIZE,
            border: `2px solid ${theme.colors.accent}`,
            opacity: hub > 0.9 ? (1 - ring) * 0.6 : 0,
            transform: `scale(${1 + ring * 0.5})`,
          }}
        />
        <div
          style={{
            width: "100%",
            height: "100%",
            opacity: clamp01(hub * 2),
            transform: `scale(${0.4 + 0.6 * hub})`,
          }}
        >
          <Glass
            fill="hero"
            style={{ width: HUB_SIZE, height: HUB_SIZE, borderRadius: HUB_SIZE, boxShadow: `0 0 90px ${theme.colors.heroGlow}, ${theme.shadow.card}` }}
            contentStyle={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", rowGap: 8 }}
          >
            <CardIcon size={104} />
            <div style={{ fontSize: 50, fontWeight: 700, lineHeight: 1.3, letterSpacing: 0 }}>পেমেন্ট</div>
          </Glass>
        </div>
      </div>

      {/* nodes */}
      {NODES.map((n, k) => {
        const p = sp(frame, fps, times[k], theme.spring.snappy);
        return (
          <div
            key={n.name}
            style={{
              position: "absolute",
              left: n.x - NODE_W / 2,
              top: n.y - NODE_H / 2,
              width: NODE_W,
              height: NODE_H,
              opacity: clamp01(p * 1.5),
              transform: `translate(${(HUB.x - n.x) * (1 - p) * 0.4}px, ${(HUB.y - n.y) * (1 - p) * 0.4}px) scale(${0.6 + 0.4 * p})`,
            }}
          >
            <Glass
              style={{ width: NODE_W, height: NODE_H, borderRadius: NODE_H / 2 }}
              contentStyle={{ display: "flex", alignItems: "center", justifyContent: "center", columnGap: 22 }}
            >
              <div style={{ width: 18, height: 18, borderRadius: 9, background: theme.colors.accent }} />
              <div style={{ fontSize: 68, fontWeight: 700, lineHeight: 1.3, letterSpacing: 0 }}>{n.name}</div>
            </Glass>
          </div>
        );
      })}
      <Sfx name="pop" at={2} />
      <Sfx name="pop" at={times[0] - 3} rate={1.0} />
      <Sfx name="pop" at={times[1] - 3} rate={1.07} />
      <Sfx name="pop" at={times[2] - 3} rate={1.14} />
    </SceneFrame>
  );
};
