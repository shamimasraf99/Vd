import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { SceneFrame } from "../components/Layers";
import { GradientText, LineMask } from "../components/Text";
import { CheckIcon, Glass, LockIcon, PlusIcon, ServerIcon } from "../components/Ui";
import { clamp01, sp, tween } from "../components/anim";
import { Sfx } from "../components/Sfx";
import { phraseAt, type SceneProps } from "../timeline";

// Style: Glass Cards + address-bar UI (hosting + free .COM)
export const S5Domain: React.FC<SceneProps> = ({ cues, exitAt }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const cue = cues[0];
  const tHost = phraseAt(cue, "হোস্টিংয়ের");
  const tFree = phraseAt(cue, "সম্পূর্ণ");
  const tCom = phraseAt(cue, ".COM");
  const tDom = phraseAt(cue, "ডোমেইন");

  const host = sp(frame, fps, tHost, theme.spring.smooth);
  const plus = sp(frame, fps, tHost + 8, theme.spring.bouncy);
  const bar = sp(frame, fps, tFree, theme.spring.smooth);
  const badge = sp(frame, fps, tFree + 10, theme.spring.bouncy);
  const comMask = tween(frame, tCom, tCom + 14, 0, 1, theme.ease.inOut);
  const label = sp(frame, fps, tDom, theme.spring.snappy);
  const check = tween(frame, tDom + 2, tDom + 10, 0, 1);
  const caret = Math.floor(frame / 8) % 2 === 0 ? 1 : 0;
  const breathe = 1 + Math.sin(frame / 22) * 0.008;

  return (
    <SceneFrame seed={5} exitAt={exitAt}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", rowGap: 60 }}>
          <LineMask delay={2} size={88}>
            <div style={{ fontSize: 88, fontWeight: 700, lineHeight: 1.3, letterSpacing: 0 }}>
              <GradientText>বাড়তি আকর্ষণ</GradientText>
            </div>
          </LineMask>

          <div style={{ display: "flex", alignItems: "center", columnGap: 40 }}>
            {/* hosting card */}
            <div
              style={{
                opacity: clamp01(host * 1.4),
                transform: `translateX(${(1 - host) * -80}px) scale(${0.95 + 0.05 * host})`,
              }}
            >
              <Glass
                style={{ width: 420, height: 300 }}
                contentStyle={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", rowGap: 18 }}
              >
                <ServerIcon size={112} />
                <div style={{ fontSize: 46, fontWeight: 600, lineHeight: 1.3, letterSpacing: 0 }}>ওয়েব হোস্টিং</div>
              </Glass>
            </div>

            <PlusIcon size={88} progress={plus} />

            {/* domain bar + label */}
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", rowGap: 26 }}>
              <div
                style={{
                  position: "relative",
                  opacity: clamp01(bar * 1.4),
                  transform: `translateX(${(1 - bar) * 90}px) scale(${(0.95 + 0.05 * bar) * breathe})`,
                }}
              >
                <Glass
                  style={{ width: 1000, height: 300, borderRadius: 150 }}
                  contentStyle={{ display: "flex", alignItems: "center", justifyContent: "center", columnGap: 30 }}
                >
                  <LockIcon size={68} />
                  <div style={{ width: 200, height: 40, borderRadius: 20, background: theme.colors.skeleton }} />
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <div
                      style={{
                        fontSize: 170,
                        fontWeight: 700,
                        lineHeight: 1.2,
                        letterSpacing: 0,
                        color: theme.colors.text,
                        clipPath: `inset(0 ${(1 - comMask) * 100}% 0 0)`,
                      }}
                    >
                      .COM
                    </div>
                    <div
                      style={{
                        width: 8,
                        height: 130,
                        marginLeft: 10,
                        borderRadius: 4,
                        background: theme.colors.accent,
                        opacity: comMask > 0.95 ? caret : 0,
                      }}
                    />
                  </div>
                </Glass>
                {/* free badge */}
                <div
                  style={{
                    position: "absolute",
                    top: -56,
                    right: 40,
                    padding: "6px 46px 12px",
                    borderRadius: 999,
                    background: theme.colors.accent,
                    color: theme.colors.bg,
                    fontSize: 84,
                    fontWeight: 700,
                    lineHeight: 1.3,
                    letterSpacing: 0,
                    boxShadow: `0 0 70px ${theme.colors.glow}`,
                    opacity: clamp01(badge * 2),
                    transform: `rotate(${5 * badge}deg) scale(${0.3 + 0.7 * badge})`,
                  }}
                >
                  ফ্রি
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  columnGap: 16,
                  fontSize: 56,
                  fontWeight: 500,
                  lineHeight: 1.3,
                  letterSpacing: 0,
                  color: theme.colors.textDim,
                  opacity: clamp01(label * 1.4),
                  transform: `translateY(${(1 - label) * 22}px)`,
                }}
              >
                <CheckIcon size={50} progress={check} />
                <span>ডোমেইন</span>
              </div>
            </div>
          </div>
        </div>
      </AbsoluteFill>
      <Sfx name="pop" at={tHost - 3} />
      <Sfx name="pop" at={tFree - 3} rate={1.07} />
      <Sfx name="click" at={tFree + 7} />
    </SceneFrame>
  );
};
