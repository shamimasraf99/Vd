import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { SceneFrame } from "../components/Layers";
import { Counter, Words, counterValue } from "../components/Text";
import { Glass } from "../components/Ui";
import { clamp01, sp } from "../components/anim";
import { Sfx } from "../components/Sfx";
import { phraseAt, type SceneProps } from "../timeline";

// Style: Data Dashboard — only numbers that are in the script (১,৬৯৯ / ১০)
export const S4Numbers: React.FC<SceneProps> = ({ cues, exitAt }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const cue = cues[0];
  const tPrice = phraseAt(cue, "১,৬৯৯");
  const tGb = phraseAt(cue, "১০ জিবি");
  const tPrem = phraseAt(cue, "প্রিমিয়াম");

  const a = sp(frame, fps, 3, theme.spring.smooth);
  const b = sp(frame, fps, tGb - 6, theme.spring.smooth);
  const gb = counterValue(frame, fps, tGb, 10);

  return (
    <SceneFrame seed={4} exitAt={exitAt}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", rowGap: 56 }}>
          <div style={{ display: "flex", columnGap: 50 }}>
            {/* price */}
            <div
              style={{
                opacity: clamp01(a * 1.4),
                transform: `translateX(${(1 - a) * -90}px) scale(${0.95 + 0.05 * a})`,
              }}
            >
              <Glass
                fill="hero"
                style={{ width: 880, height: 520, boxShadow: `0 0 80px ${theme.colors.heroGlow}, ${theme.shadow.card}` }}
                contentStyle={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", rowGap: 8 }}
              >
                <div
                  style={{
                    position: "absolute",
                    right: -120,
                    top: -120,
                    width: 360,
                    height: 360,
                    borderRadius: 180,
                    border: `2px solid ${theme.colors.borderStrong}`,
                  }}
                />
                <div style={{ fontSize: 60, fontWeight: 500, lineHeight: 1.3, color: theme.colors.text, letterSpacing: 0 }}>
                  মাত্র
                </div>
                <div style={{ display: "flex", alignItems: "baseline", columnGap: 28 }}>
                  <Counter to={1699} delay={tPrice} size={180} color={theme.colors.white} />
                  <span style={{ fontSize: 76, fontWeight: 600, lineHeight: 1.3, color: theme.colors.white, letterSpacing: 0 }}>
                    টাকা
                  </span>
                </div>
              </Glass>
            </div>

            {/* storage */}
            <div
              style={{
                opacity: clamp01(b * 1.4),
                transform: `translateX(${(1 - b) * 90}px) scale(${0.95 + 0.05 * b})`,
              }}
            >
              <Glass
                style={{ width: 780, height: 520 }}
                contentStyle={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", rowGap: 40 }}
              >
                <div style={{ display: "flex", alignItems: "baseline", columnGap: 28 }}>
                  <Counter to={10} delay={tGb} size={180} />
                  <span style={{ fontSize: 76, fontWeight: 600, lineHeight: 1.3, color: theme.colors.accent, letterSpacing: 0 }}>
                    জিবি
                  </span>
                </div>
                <div style={{ display: "flex", columnGap: 12 }}>
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div
                      key={i}
                      style={{
                        width: 52,
                        height: 22,
                        borderRadius: 11,
                        background: i < gb ? theme.colors.accent : theme.colors.skeleton,
                      }}
                    />
                  ))}
                </div>
              </Glass>
            </div>
          </div>

          <Words
            text="প্রিমিয়াম ওয়েব হোস্টিং"
            size={76}
            weight={600}
            delay={tPrem}
            accentWords={["প্রিমিয়াম"]}
          />
        </div>
      </AbsoluteFill>
      <Sfx name="pop" at={1} />
      <Sfx name="pop" at={tGb - 9} rate={1.08} />
      <Sfx name="click" at={tPrem - 3} />
    </SceneFrame>
  );
};
