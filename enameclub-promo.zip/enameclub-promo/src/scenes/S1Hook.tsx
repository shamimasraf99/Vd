import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { SceneFrame } from "../components/Layers";
import { GradientText, Words } from "../components/Text";
import { clamp01, sp, tween } from "../components/anim";
import { Sfx } from "../components/Sfx";
import { phraseAt, type SceneProps } from "../timeline";

const RINGS = [260, 380, 500, 620];
const KEY = ["নতুন", "পরিচয়"];

// Style: Kinetic Typography (hook) + line-draw rings
export const S1Hook: React.FC<SceneProps> = ({ cues, exitAt }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tKey = phraseAt(cues[0], "নতুন পরিচয়");
  const ringIn = sp(frame, fps, 0, theme.spring.smooth);
  const underline = tween(frame, tKey + 8, tKey + 24, 0, 1, theme.ease.inOut);

  return (
    <SceneFrame seed={1} exitAt={exitAt}>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <svg
          width={1400}
          height={1400}
          viewBox="0 0 1400 1400"
          style={{
            position: "absolute",
            transform: `scale(${0.82 + 0.18 * ringIn}) rotate(${frame * 0.3}deg)`,
          }}
        >
          {RINGS.map((r, i) => {
            const p = clamp01(sp(frame, fps, i * 6, theme.spring.smooth));
            const angle = ((i * 70 + frame * 0.8 * (i % 2 === 0 ? 1 : -1)) * Math.PI) / 180;
            return (
              <g key={r}>
                <circle
                  cx={700}
                  cy={700}
                  r={r}
                  fill="none"
                  stroke={i % 2 === 0 ? theme.colors.accent : theme.colors.borderStrong}
                  strokeWidth={i % 2 === 0 ? 2.5 : 1.5}
                  strokeLinecap="round"
                  pathLength={1}
                  strokeDasharray={1}
                  strokeDashoffset={1 - p}
                  opacity={p > 0.02 ? (i % 2 === 0 ? 0.6 : 0.9) : 0}
                />
                <circle
                  cx={700 + Math.cos(angle) * r}
                  cy={700 + Math.sin(angle) * r}
                  r={9}
                  fill={theme.colors.accent}
                  opacity={p}
                />
              </g>
            );
          })}
        </svg>

        <div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
          <Words
            text="আপনার অনলাইন ব্যবসাকে"
            size={92}
            weight={600}
            delay={3}
            per={5}
            accentWords={["অনলাইন"]}
          />
          <div style={{ display: "flex", columnGap: 44, justifyContent: "center", fontSize: 220, fontWeight: 700, lineHeight: 1.3, letterSpacing: 0 }}>
            {KEY.map((w, i) => {
              const p = sp(frame, fps, tKey + i * 5, theme.spring.bouncy);
              return (
                <span
                  key={w}
                  style={{
                    display: "inline-block",
                    opacity: clamp01(p * 2),
                    transform: `translateY(${(1 - p) * 40}px) scale(${1.45 - 0.45 * p})`,
                    filter: `blur(${(1 - clamp01(p)) * 14}px)`,
                  }}
                >
                  <GradientText>{w}</GradientText>
                </span>
              );
            })}
          </div>
          <div
            style={{
              width: 820 * underline,
              height: 10,
              borderRadius: 6,
              background: theme.gradients.text,
              marginTop: -6,
            }}
          />
        </div>
      </AbsoluteFill>
      <Sfx name="thud" at={1} />
      <Sfx name="pop" at={tKey - 3} />
    </SceneFrame>
  );
};
