import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { clamp01, sp, tween } from "./anim";

/** Glass card with a glossy highlight. Children sit above the gloss. */
export const Glass: React.FC<{
  fill?: "glass" | "hero";
  style?: React.CSSProperties;
  contentStyle?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ fill = "glass", style, contentStyle, children }) => (
  <div
    style={{
      position: "relative",
      overflow: "hidden",
      borderRadius: theme.radius.lg,
      background: fill === "hero" ? theme.gradients.hero : theme.gradients.glass,
      border: `1.5px solid ${theme.colors.border}`,
      boxShadow: theme.shadow.card,
      ...style,
    }}
  >
    <div
      style={{ position: "absolute", inset: 0, background: theme.gradients.gloss, pointerEvents: "none" }}
    />
    <div style={{ position: "relative", width: "100%", height: "100%", ...contentStyle }}>{children}</div>
  </div>
);

export const CheckIcon: React.FC<{ size: number; progress: number; color?: string }> = ({
  size,
  progress,
  color = theme.colors.accent,
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <path
      d="M4.5 12.5l5 5L19.5 7"
      stroke={color}
      strokeWidth={3}
      strokeLinecap="round"
      strokeLinejoin="round"
      pathLength={1}
      strokeDasharray={1}
      strokeDashoffset={1 - clamp01(progress)}
      opacity={progress > 0.02 ? 1 : 0}
    />
  </svg>
);

export const LockIcon: React.FC<{ size: number; color?: string }> = ({
  size,
  color = theme.colors.textDim,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth={2}
    strokeLinecap="round"
    strokeLinejoin="round"
    style={{ flexShrink: 0 }}
  >
    <rect x="5" y="11" width="14" height="9" rx="2.5" />
    <path d="M8 11V8a4 4 0 0 1 8 0v3" />
  </svg>
);

export const ServerIcon: React.FC<{ size: number; color?: string }> = ({
  size,
  color = theme.colors.text,
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    {[3.5, 9.5, 15.5].map((y) => (
      <g key={y}>
        <rect x="3" y={y} width="18" height="5" rx="1.6" stroke={color} strokeWidth={1.6} />
        <circle cx="7" cy={y + 2.5} r="0.9" fill={color} />
        <line x1="12" y1={y + 2.5} x2="18" y2={y + 2.5} stroke={color} strokeWidth={1.4} strokeLinecap="round" />
      </g>
    ))}
  </svg>
);

export const CardIcon: React.FC<{ size: number; color?: string }> = ({
  size,
  color = theme.colors.text,
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <rect x="2.5" y="5" width="19" height="14" rx="2.6" stroke={color} strokeWidth={1.7} />
    <line x1="2.5" y1="10" x2="21.5" y2="10" stroke={color} strokeWidth={1.7} />
    <line x1="6" y1="15" x2="10.5" y2="15" stroke={color} strokeWidth={1.7} strokeLinecap="round" />
  </svg>
);

export const PlusIcon: React.FC<{ size: number; progress: number; color?: string }> = ({
  size,
  progress,
  color = theme.colors.accent,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth={2.6}
    strokeLinecap="round"
    style={{ transform: `rotate(${(1 - clamp01(progress)) * -90}deg)`, opacity: clamp01(progress * 1.5) }}
  >
    <line x1="12" y1="4" x2="12" y2="20" />
    <line x1="4" y1="12" x2="20" y2="12" />
  </svg>
);

/** Feature pill with a self-drawing check mark. */
export const Pill: React.FC<{ label: string; delay: number; size?: number }> = ({
  label,
  delay,
  size = 60,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = sp(frame, fps, delay, theme.spring.bouncy);
  const check = tween(frame, delay + 6, delay + 18, 0, 1);
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 16,
        padding: "12px 36px 12px 26px",
        borderRadius: 999,
        background: theme.gradients.glass,
        border: `1.5px solid ${theme.colors.borderStrong}`,
        fontSize: size,
        fontWeight: 600,
        lineHeight: 1.3,
        letterSpacing: 0,
        color: theme.colors.text,
        opacity: clamp01(p * 1.5),
        transform: `scale(${0.7 + 0.3 * p}) translateY(${(1 - p) * 24}px)`,
      }}
    >
      <CheckIcon size={size * 0.8} progress={check} />
      <span>{label}</span>
    </div>
  );
};

/** Skeleton block used inside the browser mock-up. */
export const Skel: React.FC<{
  p: number;
  w: number | string;
  h: number;
  r?: number;
  fill?: string;
  style?: React.CSSProperties;
}> = ({ p, w, h, r = 10, fill = theme.colors.skeleton, style }) => (
  <div
    style={{
      width: w,
      height: h,
      borderRadius: r,
      background: fill,
      opacity: clamp01(p * 1.4),
      transform: `translateY(${(1 - p) * 18}px) scale(${0.94 + 0.06 * p})`,
      flexShrink: 0,
      ...style,
    }}
  />
);
