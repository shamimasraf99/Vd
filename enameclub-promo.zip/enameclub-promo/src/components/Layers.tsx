import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";

// Layer 1: background mesh (never flat)
export const BgMesh: React.FC<{ seed?: number }> = ({ seed = 0 }) => {
  const frame = useCurrentFrame();
  const d1 = Math.sin((frame + seed * 40) / 55) * 60;
  const d2 = Math.cos((frame + seed * 25) / 70) * 50;
  return (
    <AbsoluteFill style={{ background: theme.gradients.bg }}>
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -520,
          left: -380 + d1,
          background: `radial-gradient(circle, ${theme.colors.heroGlow}, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -460,
          right: -300 - d2,
          background: `radial-gradient(circle, ${theme.colors.glow}, transparent 65%)`,
          opacity: 0.45,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${theme.colors.dot} 2px, transparent 2.4px)`,
          backgroundSize: "64px 64px",
        }}
      />
    </AbsoluteFill>
  );
};

// Layer 4: colour grade
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill
      style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.2 }}
    />
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${theme.colors.shade}, transparent 26%, transparent 74%, ${theme.colors.shade})`,
        opacity: 0.35,
      }}
    />
  </AbsoluteFill>
);

// Layer 5a: procedural grain
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

// Layer 5b: vignette (topmost)
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: `radial-gradient(ellipse at center, transparent 56%, ${theme.colors.shade} 100%)`,
      opacity: 0.6,
    }}
  />
);

/** Five-layer stack: bg mesh -> content -> grade -> grain -> vignette. Content exits fast before the sweep. */
export const SceneFrame: React.FC<{
  seed?: number;
  exitAt?: number;
  children: React.ReactNode;
}> = ({ seed = 0, exitAt, children }) => {
  const frame = useCurrentFrame();
  const x =
    exitAt === undefined
      ? 0
      : interpolate(frame, [exitAt - theme.timing.exit, exitAt - 1], [0, 1], {
          easing: theme.ease.in,
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        });
  return (
    <AbsoluteFill>
      <BgMesh seed={seed} />
      <AbsoluteFill
        style={{
          opacity: 1 - x,
          transform: `translateY(${-x * 36}px) scale(${1 - x * 0.02})`,
        }}
      >
        {children}
      </AbsoluteFill>
      <Grade />
      <Grain />
      <Vignette />
    </AbsoluteFill>
  );
};
