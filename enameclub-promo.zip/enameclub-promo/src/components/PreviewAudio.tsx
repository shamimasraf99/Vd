import React, { useEffect, useRef, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { PLAY_VOICEOVER_IN_RENDER, PLAY_VOICEOVER_IN_STUDIO, VOICEOVER_FILE } from "../config";

/** Plays public/voiceover.mp3 if it exists (silently skipped otherwise). Off in renders by default. */
export const PreviewAudio: React.FC = () => {
  const enabled = getRemotionEnvironment().isRendering
    ? PLAY_VOICEOVER_IN_RENDER
    : PLAY_VOICEOVER_IN_STUDIO;
  const [handle] = useState(() => (enabled ? delayRender("voiceover check") : null));
  const [exists, setExists] = useState(false);
  const cleared = useRef(false);

  useEffect(() => {
    if (handle === null) return;
    let alive = true;
    const finish = () => {
      if (!cleared.current) {
        cleared.current = true;
        continueRender(handle);
      }
    };
    fetch(staticFile(VOICEOVER_FILE), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive) setExists(r.ok && !type.includes("text/html"));
      })
      .catch(() => undefined)
      .finally(finish);
    return () => {
      alive = false;
    };
  }, [handle]);

  if (!enabled || !exists) return null;
  return <Audio src={staticFile(VOICEOVER_FILE)} />;
};
