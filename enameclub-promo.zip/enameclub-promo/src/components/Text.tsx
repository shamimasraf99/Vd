import React from "react";
import { spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { bnNum } from "../bn";
import { clamp01, sp, tween } from "./anim";

type WordsProps = {
  text: string;
  delay?: number;
  per?: number;
  size: number;
  weight?: number;
  color?: string;
  accentWords?: string[];
  accentColor?: string;
  align?: "center" | "flex-start";
  maxWidth?: number;
  style?: React.CSSProperties;
};

/** Word-by-word staggered reveal. Splits ONLY on spaces — Bengali clusters are never broken. */
export const Words: React.FC<WordsProps> = ({
  text,
  delay = 0,
  per = theme.timing.wordStagger,
  size,
  weight = 700,
  color = theme.colors.text,
  accentWords = [],
  accentColor = theme.colors.accent,
  align = "center",
  maxWidth,
  style,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align,
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.02),
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.32,
        letterSpacing: 0,
        color,
        maxWidth,
        ...style,
      }}
    >
      {text.split(" ").map((w, i) => {
        const p = sp(frame, fps, delay + i * per, theme.spring.snappy);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: clamp01(p * 1.3),
              transform: `translateY(${(1 - p) * size * 0.32}px) scale(${0.94 + 0.06 * p})`,
              color: accentWords.includes(w) ? accentColor : undefined,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** Line mask reveal: the line rises out of a clipping box (padded so Bengali matras are not cut). */
export const LineMask: React.FC<{
  delay?: number;
  size: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ delay = 0, size, children, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = clamp01(sp(frame, fps, delay, theme.spring.smooth));
  return (
    <div
      style={{
        overflow: "hidden",
        paddingTop: size * 0.2,
        paddingBottom: size * 0.26,
        ...style,
      }}
    >
      <div style={{ transform: `translateY(${(1 - p) * 112}%)` }}>{children}</div>
    </div>
  );
};

/** Highlight sweep: a hero-coloured marker wipes left -> right behind the text. */
export const MarkerSweep: React.FC<{
  delay: number;
  padX?: number;
  radius?: number;
  children: React.ReactNode;
}> = ({ delay, padX = 22, radius = 16, children }) => {
  const frame = useCurrentFrame();
  const p = tween(frame, delay, delay + 14, 0, 1, theme.ease.inOut);
  return (
    <span style={{ position: "relative", display: "inline-block", padding: `0 ${padX}px` }}>
      <span
        style={{
          position: "absolute",
          left: 0,
          top: "10%",
          bottom: "6%",
          width: `${p * 100}%`,
          background: theme.gradients.sweep,
          borderRadius: radius,
        }}
      />
      <span style={{ position: "relative" }}>{children}</span>
    </span>
  );
};

/** Gradient keyword (padded so the clipped gradient covers Bengali ascenders/descenders). */
export const GradientText: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({
  children,
  style,
}) => (
  <span
    style={{
      display: "inline-block",
      padding: "0.06em 0.06em 0.2em",
      margin: "-0.06em -0.06em -0.2em",
      background: theme.gradients.text,
      WebkitBackgroundClip: "text",
      backgroundClip: "text",
      WebkitTextFillColor: "transparent",
      color: "transparent",
      ...style,
    }}
  >
    {children}
  </span>
);

export const counterValue = (frame: number, fps: number, delay: number, to: number) => {
  const p = spring({ frame: frame - delay, fps, config: theme.spring.count });
  return p > 0.998 ? to : Math.round(to * clamp01(p));
};

const digitWidth = (ch: string, size: number) => (ch === "," ? size * 0.3 : size * 0.62);

/** Counter roll in Bengali digits. Fixed-width cells so nothing jitters while it counts. */
export const Counter: React.FC<{
  to: number;
  delay: number;
  size: number;
  weight?: number;
  color?: string;
}> = ({ to, delay, size, weight = 700, color = theme.colors.text }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const str = bnNum(counterValue(frame, fps, delay, to));
  const total = bnNum(to)
    .split("")
    .reduce((s, ch) => s + digitWidth(ch, size), 0);
  return (
    <div
      style={{
        display: "inline-flex",
        justifyContent: "flex-end",
        width: total,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.2,
        letterSpacing: 0,
        color,
      }}
    >
      {str.split("").map((ch, i) => (
        <span
          key={i}
          style={{ display: "inline-block", width: digitWidth(ch, size), textAlign: "center" }}
        >
          {ch}
        </span>
      ))}
    </div>
  );
};
