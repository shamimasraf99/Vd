import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { sfxMeta } from "../sfxMeta";
import { FPS } from "../timeline";

export type SfxName = keyof typeof sfxMeta;

/** One short UI sound. `at` is a frame in the current scene; pass (visual frame - 3) so it lands in sync. */
export const Sfx: React.FC<{ name: SfxName; at: number; volume?: number; rate?: number }> = ({
  name,
  at,
  volume,
  rate = 1,
}) => {
  const meta = sfxMeta[name];
  const frames = Math.ceil((meta.durationSec / rate) * FPS) + 2;
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={frames} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={volume ?? meta.volume} playbackRate={rate} />
    </Sequence>
  );
};
