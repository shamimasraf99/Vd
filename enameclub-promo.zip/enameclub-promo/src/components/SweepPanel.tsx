import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { WIDTH } from "../timeline";
import { tween } from "./anim";
import { Sfx } from "./Sfx";

export const SWEEP_FRAMES = 18;
const PANEL_W = 2800;

/** Scene transition: a brand panel wipes across; the scene cut happens behind it at its midpoint. */
export const SweepPanel: React.FC = () => {
  const frame = useCurrentFrame();
  const p = tween(frame, 0, SWEEP_FRAMES - 1, 0, 1, theme.ease.inOut);
  const x = -PANEL_W - 300 + p * (WIDTH + PANEL_W + 600);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          top: -120,
          bottom: -120,
          left: 0,
          width: PANEL_W,
          transform: `translateX(${x}px) skewX(-14deg)`,
          background: theme.gradients.sweep,
        }}
      >
        <div
          style={{
            position: "absolute",
            top: 0,
            bottom: 0,
            right: 0,
            width: 16,
            background: theme.colors.accent,
          }}
        />
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: theme.gradients.gloss,
          }}
        />
      </div>
      <Sfx name="whoosh" at={0} />
    </AbsoluteFill>
  );
};
