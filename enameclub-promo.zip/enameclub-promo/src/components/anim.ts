import { interpolate, spring, type SpringConfig } from "remotion";
import { theme } from "../theme";

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

/** spring progress (0 -> 1) starting at `delay` */
export const sp = (
  frame: number,
  fps: number,
  delay: number,
  config: Partial<SpringConfig> = theme.spring.smooth
) => spring({ frame: frame - delay, fps, config });

/** eased, clamped tween between two frames */
export const tween = (
  frame: number,
  from: number,
  to: number,
  a: number,
  b: number,
  easing: (t: number) => number = theme.ease.out
) =>
  interpolate(frame, [from, to], [a, b], {
    easing,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
