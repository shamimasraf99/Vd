// Synthesizes a small, soft UI SFX kit (mono 16-bit WAV, 44.1 kHz) into public/sfx
// and writes src/sfxMeta.ts with the MEASURED durations and matched volumes.
import fs from "node:fs";

const SR = 44100;
const TARGET_RMS = 0.2; // loudness of the active part before the Audio volume is applied
const PEAK_CAP = 0.89;

let seed = 20260711; // deterministic noise
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return (seed / 4294967296) * 2 - 1;
};

const make = (sec) => new Float32Array(Math.floor(sec * SR));
const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y += a * (v - y)));
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
};
// very small room: three quiet taps
const reverb = (x) => {
  const tail = Math.floor(0.06 * SR);
  const out = new Float32Array(x.length + tail);
  const taps = [[0.017, 0.26], [0.031, 0.17], [0.047, 0.1]];
  for (let i = 0; i < x.length; i++) {
    out[i] += x[i];
    for (const [d, g] of taps) out[i + Math.floor(d * SR)] += x[i] * g;
  }
  return out;
};
const fadeEdges = (x, ms = 8) => {
  const n = Math.floor((ms / 1000) * SR);
  for (let i = 0; i < n && i < x.length; i++) {
    x[x.length - 1 - i] *= i / n;
  }
  return x;
};

const pop = () => {
  const x = make(0.22);
  let phase = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 150 + 380 * Math.exp(-t / 0.035); // fast downward pitch
    phase += (2 * Math.PI * f) / SR;
    const env = Math.min(1, t / 0.004) * Math.exp(-t / 0.055);
    x[i] = (Math.sin(phase) + 0.15 * Math.sin(2 * phase)) * env;
  }
  return reverb(lowpass(x, 5200));
};

const click = () => {
  const x = make(0.12);
  let phase = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    phase += (2 * Math.PI * 1900) / SR;
    const burst = rnd() * Math.exp(-t / 0.005);
    const tone = 0.35 * Math.sin(phase) * Math.exp(-t / 0.012);
    x[i] = (burst + tone) * Math.min(1, t / 0.0008);
  }
  return reverb(lowpass(highpass(x, 2200), 9000));
};

const whoosh = () => {
  const x = make(0.7);
  const n = x.length;
  let low = 0, band = 0;
  const q = 0.55;
  for (let i = 0; i < n; i++) {
    const t = i / n;
    const fc = 380 + 2900 * Math.pow(Math.sin(Math.PI * Math.min(1, t * 1.15)), 1.2);
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    const input = rnd();
    low += f * band;
    const high = input - low - q * band;
    band += f * high;
    const env = Math.pow(Math.sin(Math.PI * t), 2); // fade in / out
    x[i] = band * env;
  }
  return reverb(lowpass(x, 6000));
};

const chime = () => {
  const x = make(0.5);
  const partials = [[880, 1, 0.16], [1320, 0.5, 0.11], [1760, 0.3, 0.08], [2640, 0.12, 0.05]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let s = 0;
    for (const [f, a, d] of partials) s += a * Math.sin(2 * Math.PI * f * t) * Math.exp(-t / d);
    x[i] = s * Math.min(1, t / 0.003);
  }
  return reverb(lowpass(x, 7000));
};

const thud = () => {
  const x = make(0.32);
  let phase = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 48 + 62 * Math.exp(-t / 0.05);
    phase += (2 * Math.PI * f) / SR;
    x[i] = Math.sin(phase) * Math.min(1, t / 0.008) * Math.exp(-t / 0.09);
  }
  return reverb(lowpass(x, 800));
};

const kit = { pop, click, whoosh, chime, thud };

const toWav = (x) => {
  const data = Buffer.alloc(x.length * 2);
  for (let i = 0; i < x.length; i++) data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, x[i])) * 32767), i * 2);
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + data.length, 4); h.write("WAVE", 8);
  h.write("fmt ", 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22);
  h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34);
  h.write("data", 36); h.writeUInt32LE(data.length, 40);
  return Buffer.concat([h, data]);
};

const stats = (x) => {
  let peak = 0, sum = 0, cnt = 0;
  for (const v of x) peak = Math.max(peak, Math.abs(v));
  for (const v of x) if (Math.abs(v) > peak * 0.05) { sum += v * v; cnt++; }
  return { peak, rms: Math.sqrt(sum / Math.max(1, cnt)) };
};

fs.mkdirSync("public/sfx", { recursive: true });
const meta = {};
console.log("name     dur(s)  peak   rmsActive  clipped  volume");
for (const [name, fn] of Object.entries(kit)) {
  let x = fadeEdges(fn());
  let s = stats(x);
  let gain = TARGET_RMS / s.rms;
  gain = Math.min(gain, PEAK_CAP / s.peak); // never clip
  x = x.map((v) => v * gain);
  s = stats(x);
  const clipped = x.filter((v) => Math.abs(v) >= 0.999).length;
  const durationSec = x.length / SR;
  // match perceived level: quieter-by-rms files (peak-limited) get a slightly higher Audio volume
  const volume = Math.round(Math.min(0.35, Math.max(0.2, 0.28 * (TARGET_RMS / s.rms))) * 100) / 100;
  fs.writeFileSync(`public/sfx/${name}.wav`, toWav(x));
  meta[name] = { durationSec: Math.round(durationSec * 1000) / 1000, volume };
  console.log(`${name.padEnd(8)} ${durationSec.toFixed(3)}   ${s.peak.toFixed(3)}  ${s.rms.toFixed(3)}      ${clipped}        ${volume}`);
}

fs.writeFileSync(
  "src/sfxMeta.ts",
  "// GENERATED by scripts/make-sfx.mjs — measured durations and matched volumes.\n" +
    "export const sfxMeta = " + JSON.stringify(meta, null, 2) + " as const;\n"
);
